local environment = system.getVersion()

local lastPrintTime = 0  -- Store the last time the debug was printed
local printInterval = 2   -- Interval in seconds

local function create()
	-- this function is called whenever the widget is first initialised
    -- it's usefull for setting up widget variables or just
    -- general stuff you need.

	local widget = {}
    return widget 
end

local function configure(widget)

end

local function paint(widget)

end

local function wakeup(widget)
    -- this is the main loop that ethos calls every couple of ms

    local currentTime = os.clock() -- Get the current time in seconds

    if currentTime - lastPrintTime >= printInterval then
        if rfsuite and rfsuite.bg.active() then
            -- Useful info
            print("Craft Name: " .. (rfsuite.config.craftName or "-"))
            print("Model Id: " .. (rfsuite.config.modelID or "-"))
			print("API Version: " .. (rfsuite.config.apiVersion or "-"))
			print("Tail Mode: " .. (rfsuite.config.tailMode or "-"))
			print("Swash Mode: " .. (rfsuite.config.swashMode or "-"))
			print("Servo count: " .. (rfsuite.config.servoCount or "-"))
			rfsuite.utils.log("Governor mode: " .. (governorMode or "-"))

            -- Get a sensor source regardless of protocol
            -- You can see sensor names in rfsuite/tasks/telemetry/telemetry.lua 
            -- Look at the sensorTable
            local armflags = rfsuite.bg.telemetry.getSensorSource("armflags")
            print("Arm Flags: " .. (armflags:value() or "-"))

            local rpm = rfsuite.bg.telemetry.getSensorSource("rpm")
            print("Headspeed: " .. (rpm:value() or "-"))

            local voltage = rfsuite.bg.telemetry.getSensorSource("voltage")
            print("Voltage: " .. (voltage:value() or "-"))
        else
            print("Init...")
        end

        lastPrintTime = currentTime -- Update the last print time
    end

    return
end


local function init()
	-- this is where we 'setup' the widget
	
	local key = "rfglbs"			-- unique key - keep it less that 8 chars
	local name = "Rotorflight Globals"		-- name of widget

    system.registerWidget(
        {
            key = key,					-- unique project id
            name = name,				-- name of widget
            create = create,			-- function called when creating widget
            configure = configure,		-- function called when configuring the widget (use ethos forms)
            paint = paint,				-- function called when lcd.invalidate() is called
            wakeup = wakeup,			-- function called as the main loop
            read = read,				-- function called when starting widget and reading configuration params
            write = write,				-- function called when saving values / changing values in the configuration menu
			event = event,				-- function called when buttons or screen clips occur
			menu = menu,				-- function called to add items to the menu
			persistent = false,			-- true or false to make the widget carry values between sessions and models (not safe imho)
        }
    )

end

return {init = init}
