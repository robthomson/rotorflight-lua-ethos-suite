This folder stores logs.

Please do not delete it.