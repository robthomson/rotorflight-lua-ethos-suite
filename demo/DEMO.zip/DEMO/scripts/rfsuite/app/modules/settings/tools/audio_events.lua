

local config = {}
local enableWakeup = false

local function sensorNameMap(sensorList)
    local nameMap = {}
    for _, sensor in ipairs(sensorList) do
        nameMap[sensor.key] = sensor.name
    end
    return nameMap
end

local function setFieldEnabled(field, enabled)
    if field and field.enable then field:enable(enabled) end
end

local function openPage(pageIdx, title, script)
    enableWakeup = true
    if not rfsuite.app.navButtons then rfsuite.app.navButtons = {} end
    rfsuite.app.triggers.closeProgressLoader = true
    form.clear()

    rfsuite.app.lastIdx    = pageIdx
    rfsuite.app.lastTitle  = title
    rfsuite.app.lastScript = script

    rfsuite.app.ui.fieldHeader(
        "Settings" .. " / " .. "Audio" .. " / " .. "Events"
    )
    rfsuite.app.formLineCnt = 0

    local formFieldCount = 0

     local app = rfsuite.app
    if app.formFields then
        for i = 1, #app.formFields do app.formFields[i] = nil end
    end
    if app.formLines then
        for i = 1, #app.formLines do app.formLines[i] = nil end
    end       

    -- Build event name map
    local eventList = rfsuite.tasks.events.telemetry.eventTable
    local eventNames = sensorNameMap(rfsuite.tasks.telemetry.listSensors())

    -- Prepare working config as a shallow copy of events preferences
    local savedEvents = rfsuite.preferences.events or {}
    for k, v in pairs(savedEvents) do config[k] = v end

    local escFields, becFields, fuelFields = {}, {}, {}

    -- Arming Flags Panel
    local armEnabled = config.armflags == true
    local armPanel = form.addExpansionPanel("Arming Flags")
    armPanel:open(armEnabled)
    local armLine = armPanel:addLine("Arming Flags")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    rfsuite.app.formFields[formFieldCount] = form.addBooleanField(
        armLine, nil,
        function() return config.armflags end,
        function(val) config.armflags = val end
    )

    -- Governor Panel
    local govEnabled = config.governor == true
    local govPanel = form.addExpansionPanel("Governor State")
    govPanel:open(govEnabled)
    local govLine = govPanel:addLine("Governor State")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    rfsuite.app.formFields[formFieldCount] = form.addBooleanField(
        govLine, nil,
        function() return config.governor end,
        function(val) config.governor = val end
    )

    -- Voltage Low Alert Panel
    local voltEnabled = config.voltage == true
    local voltPanel = form.addExpansionPanel("Voltage")
    voltPanel:open(voltEnabled)
    local voltLine = voltPanel:addLine("Voltage")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    rfsuite.app.formFields[formFieldCount] = form.addBooleanField(
        voltLine, nil,
        function() return config.voltage end,
        function(val) config.voltage = val end
    )

    -- Rates/PID Profile Panel
    local ratesEnabled = (config.pid_profile == true) or (config.rate_profile == true)
    local ratesPanel = form.addExpansionPanel("PID/Rates Profile")
    ratesPanel:open(ratesEnabled)
    local pidLine = ratesPanel:addLine("PID Profile")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    rfsuite.app.formFields[formFieldCount] = form.addBooleanField(
        pidLine, nil,
        function() return config.pid_profile end,
        function(val) config.pid_profile = val end
    )
    local rateLine = ratesPanel:addLine("Rate Profile")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    rfsuite.app.formFields[formFieldCount] = form.addBooleanField(
        rateLine, nil,
        function() return config.rate_profile end,
        function(val) config.rate_profile = val end
    )

    -- ESC Temp Alert Panel
    local escEnabled = config.temp_esc == true
    local escPanel = form.addExpansionPanel("ESC Temperature")
    escPanel:open(escEnabled)
    local escEnable = escPanel:addLine("ESC Temperature")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    escFields.enable = formFieldCount
    rfsuite.app.formFields[formFieldCount] = form.addBooleanField(
        escEnable, nil,
        function() return config.temp_esc end,
        function(val)
            config.temp_esc = val
            setFieldEnabled(rfsuite.app.formFields[escFields.thresh], val)
        end
    )
    local escThresh = escPanel:addLine("Threshold (°)")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    escFields.thresh = formFieldCount
    rfsuite.app.formFields[formFieldCount] = form.addNumberField(
        escThresh, nil, 60, 300,
        function() return config.escalertvalue or 90 end,
        function(val) config.escalertvalue = val end,
        1
    )
    rfsuite.app.formFields[formFieldCount]:suffix("°")
    setFieldEnabled(rfsuite.app.formFields[escFields.thresh], escEnabled)

    -- Adjustments Panel
    local adjEnabled = (config.adj_f == true) or (config.adj_v == true)
    local adjPanel = form.addExpansionPanel("Adjustment Callouts")
    adjPanel:open(adjEnabled)

    -- Speak the adjust *function name* (e.g., "pitch", "rate", etc.)
    local adjFuncLine = adjPanel:addLine("Adjustment Function")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    rfsuite.app.formFields[formFieldCount] = form.addBooleanField(
    adjFuncLine, nil,
    function() return config.adj_f == true end,   -- default OFF
    function(val) config.adj_f = val end
    )

    -- Speak the adjust *value* (e.g., the number after you change it)
    local adjValueLine = adjPanel:addLine("Adjustment Value")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    rfsuite.app.formFields[formFieldCount] = form.addBooleanField(
    adjValueLine, nil,
    function() return config.adj_v == true end,   -- default OFF
    function(val) config.adj_v = val end
    )

    -- Smart Fuel Alert Panel
    local fuelEnabled = config.smartfuel == true
    local fuelPanel = form.addExpansionPanel("Fuel")
    fuelPanel:open(fuelEnabled)
    local fuelEnable = fuelPanel:addLine("Fuel")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    fuelFields.enable = formFieldCount
    rfsuite.app.formFields[formFieldCount] = form.addBooleanField(
        fuelEnable, nil,
        function() return config.smartfuel end,
        function(val)
            config.smartfuel = val
            setFieldEnabled(rfsuite.app.formFields[fuelFields.callout], val)
            setFieldEnabled(rfsuite.app.formFields[fuelFields.repeats], val)
            setFieldEnabled(rfsuite.app.formFields[fuelFields.haptic], val)
        end
    )
    local calloutChoices = {
        {"Default (Only at 10%)", 0},
        {"50% and 5%", 5},
        {"Every 10%", 10},
        {"Every 20%", 20},
        {"Every 25%", 25},
        {"Every 50%", 50},
    }
    local fuelThresh = fuelPanel:addLine("Callout %")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    fuelFields.callout = formFieldCount
    rfsuite.app.formFields[formFieldCount] = form.addChoiceField(
        fuelThresh, nil,
        calloutChoices,
        function()
            local v = config.smartfuelcallout
            if v == nil or v == false then return 10 end
            return v
        end,
        function(val) config.smartfuelcallout = val end
    )
    setFieldEnabled(rfsuite.app.formFields[fuelFields.callout], fuelEnabled)

    local fuelRepeats = fuelPanel:addLine("Repeats below 0%")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    fuelFields.repeats = formFieldCount
    rfsuite.app.formFields[formFieldCount] = form.addNumberField(
        fuelRepeats, nil, 1, 10,
        function() return config.smartfuelrepeats or 1 end,
        function(val) config.smartfuelrepeats = val end,
        1
    )
    rfsuite.app.formFields[formFieldCount]:suffix("x")
    setFieldEnabled(rfsuite.app.formFields[fuelFields.repeats], fuelEnabled)

    local fuelHaptic = fuelPanel:addLine("Haptic below 0%")
    formFieldCount = formFieldCount + 1
    rfsuite.app.formLineCnt = rfsuite.app.formLineCnt + 1
    fuelFields.haptic = formFieldCount
    rfsuite.app.formFields[formFieldCount] = form.addBooleanField(
        fuelHaptic, nil,
        function() return config.smartfuelhaptic == true end,
        function(val) config.smartfuelhaptic = val end
    )
    setFieldEnabled(rfsuite.app.formFields[fuelFields.haptic], fuelEnabled)

    setFieldEnabled(rfsuite.app.formFields[escFields.enable], true)
    setFieldEnabled(rfsuite.app.formFields[becFields.enable], true)
    setFieldEnabled(rfsuite.app.formFields[fuelFields.enable], true)

    rfsuite.app.navButtons.save = true
end

local function onNavMenu()
    rfsuite.app.ui.progressDisplay(nil,nil,true)
    rfsuite.app.ui.openPage(
        pageIdx,
        "Settings",
        "settings/tools/audio.lua"
    )
end

local function onSaveMenu()
    local buttons = {
        {
            label  = "                OK                ",
            action = function()
                local msg = "Save current page to radio?"
                rfsuite.app.ui.progressDisplaySave(msg:gsub("%?$", "."))
                for key, value in pairs(config) do
                    rfsuite.preferences.events[key] = value
                end
                rfsuite.ini.save_ini_file(
                    "SCRIPTS:/" .. rfsuite.config.preferences .. "/preferences.ini",
                    rfsuite.preferences
                )
                rfsuite.app.triggers.closeSave = true
                return true
            end,
        },
        {
            label  = "CANCEL",
            action = function()
                return true
            end,
        },
    }

    form.openDialog({
        width   = nil,
        title   = "Save settings",
        message = "Save current page to radio?",
        buttons = buttons,
        wakeup  = function() end,
        paint   = function() end,
        options = TEXT_LEFT,
    })
end

local function event(widget, category, value, x, y)
    if category == EVT_CLOSE and value == 0 or value == 35 then
        rfsuite.app.ui.openPage(
            pageIdx,
            "Settings",
            "settings/tools/audio.lua"
        )
        return true
    end
end

return {
    event      = event,
    openPage   = openPage,
    onNavMenu  = onNavMenu,
    onSaveMenu = onSaveMenu,
    navButtons = {
        menu   = true,
        save   = true,
        reload = false,
        tool   = false,
        help   = false,
    },
    API = {},
}
