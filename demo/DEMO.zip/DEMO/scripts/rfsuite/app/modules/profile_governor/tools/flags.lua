
local activateWakeup = false
local governorDisabledMsg = false



local apidata = {
        api = {
            [1] = 'GOVERNOR_PROFILE',
        },
        formdata = {
            labels = {

            },
            fields = {
                {t = "FC Throttle Curve",       mspapi = 1, apikey = "governor_flags->fc_throttle_curve", type = 4},
                {t = "TX Precomp Curve",       mspapi = 1, apikey = "governor_flags->tx_precomp_curve", type = 4},
                {t = "Fallback Precomp",       mspapi = 1, apikey = "governor_flags->fallback_precomp", type = 4},
                {t = "Voltage Comp",           mspapi = 1, apikey = "governor_flags->voltage_comp", type = 4},
                {t = "PID Spoolup",            mspapi = 1, apikey = "governor_flags->pid_spoolup", type = 4},
                {t = "HS Adjustment",          mspapi = 1, apikey = "governor_flags->hs_adjustment", type = 4},
                {t = "Dyn. Min Throttle",       mspapi = 1, apikey = "governor_flags->dyn_min_throttle", type = 4},
                {t = "Autorotation",           mspapi = 1, apikey = "governor_flags->autorotation", type = 4},
                {t = "Suspend",                mspapi = 1, apikey = "governor_flags->suspend", type = 4},
                {t = "Bypass",                 mspapi = 1, apikey = "governor_flags->bypass", type = 4},
            }
        }
    }


local function postLoad(self)
    rfsuite.app.triggers.closeProgressLoader = true
    activateWakeup = true
end

local function wakeup()

    if activateWakeup == true  and rfsuite.tasks.msp.mspQueue:isProcessed() then

        -- update active profile
        -- the check happens in postLoad          
        if rfsuite.session.activeProfile ~= nil then
            rfsuite.app.formFields['title']:value(rfsuite.app.Page.title .." / " .. "Flags" .. " #" .. rfsuite.session.activeProfile)
        end

        if rfsuite.session.governorMode == 0 then
            if governorDisabledMsg == false then
                governorDisabledMsg = true

                -- disable save button
                rfsuite.app.formNavigationFields['save']:enable(false)
                -- disable reload button
                rfsuite.app.formNavigationFields['reload']:enable(false)
                -- add field to formFields
                rfsuite.app.formLines[#rfsuite.app.formLines + 1] = form.addLine("Rotorflight governor is not enabled")

            end
        end

    end

end

local function event(widget, category, value, x, y)
    -- if close event detected go to section home page
    if category == EVT_CLOSE and value == 0 or value == 35 then
        rfsuite.app.ui.openPage(pidx, title, "profile_governor/governor.lua")  
        return true
    end
end


local function onNavMenu()
    rfsuite.app.ui.progressDisplay()
    rfsuite.app.ui.openPage(pidx, title, "profile_governor/governor.lua")  
    return true
end

return {
    apidata = apidata,
    title = "Governor",
    reboot = false,
    event = event,
    onNavMenu = onNavMenu,
    refreshOnProfileChange = true,
    eepromWrite = true,
    postLoad = postLoad,
    wakeup = wakeup,
    API = {},
}
