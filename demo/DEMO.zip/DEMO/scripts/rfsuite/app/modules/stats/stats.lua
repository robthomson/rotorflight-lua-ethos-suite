

local apidata = {
    api = {
        [1] = "FLIGHT_STATS_INI"
    },
    formdata = {
        labels = {
        },
        fields = {
            {t = "Total Flight Time", mspapi = 1, apikey = "totalflighttime"},
            {t = "Flight Count", mspapi = 1, apikey = "flightcount"},
            -- {t = "Last Flight Time", mspapi = 1, apikey = "lastflighttime"}, -- turned off as no point editing this?
        }
    }                 
}

return {
    apidata = apidata,
    eepromWrite = false,
    reboot = false,
    API = {},
}
